#ifndef OPENGL_H
#define OPENGL_H

// OpenGL:
#include <GL/glew.h>        // GLEW library
#include <GLFW/glfw3.h>     // GLFW library

#endif //OPENGL_H
